// 引入express框架文件
const express = require("express");
// 调用express函数
const app = express();
// 导入 banner.js 模块
const bannerRouter = require("./routes/banner");
const listRouter = require("./routes/list");

// 使用 banner 路由模块
app.use("/banner",bannerRouter);
app.use("/list",listRouter);

// 设置静态资源
app.use('/static',express.static("public"))

// 监听服务端口
app.listen(
   8080,
   function(){
     console.log("服务启动了")
     console.log("http://127.0.0.1:8080")
   }
)

