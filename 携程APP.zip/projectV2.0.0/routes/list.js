const express = require("express")
const router = express.Router()
const fs = require("fs")
const path = require("path")
router.get("/content",function(req,res){
    // 定义变量接收前端提交的参数
    let page = req.query.page || 0;
    let pageSize = req.query.pageSize || 2;
    // 定义数组的开始索引值
    let startIndex = (page-0) * (pageSize-0);
    // 定义数组的结束索引值
    let endIndex = startIndex + (pageSize-0);
    let url = path.resolve(__dirname,"../data/list.txt");
    fs.readFile(url,"utf-8",function(err,data){
        if(err){
            res.send({code:"-1",message:"读取数据失败"})
        }else {
            // 数组
            let arr = JSON.parse(data);
            // 截取数组指定的数据
            let result = arr.slice(startIndex,endIndex);
            // 字符串
            let str = JSON.stringify(result);
             // 响应给客户端的数据
             res.send(`jsonp523('{"code":"200","data":${str}}')`);
        }
    })
})
module.exports = router;