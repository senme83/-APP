// 导入express模块
const express = require("express")
const fs = require("fs")
const path = require("path");
// 路由模块
const router = express.Router()
// 接口地址1： 首页轮播图数据
router.get("/index",function(req,res){
    // 读取文档内容 banner.txt 
    // __dirname 是全局变量 表示当前目录的绝对路径
    let url = path.resolve(__dirname,"../data/banner.txt");
    fs.readFile(url,'utf-8',function(err,data){
        if(err){ 
            res.send({"code":"-1","message":"获取数据失败"})
        }else {
            // 首先把读取的文本转json对象再转json字符串
            let str = JSON.stringify(JSON.parse(data));
            // 响应给客户端的数据
            res.send(`jsonp522('{"code":"200","data":${str}}')`);
        }
    })
})


// 导出当前的路由
module.exports = router;