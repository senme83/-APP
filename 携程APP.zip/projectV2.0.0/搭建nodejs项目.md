## 搭建nodejs项目
### Express 框架
1. 创建project项目文件夹
2. 在project文件夹下打开命令面板
3. 输入 npm init -y  初始化当前目录
生成package.json文件
该文件用于描述项目，配置文件，记录下载的依赖
4. 创建项目入口文件 app.js
5. 通过执行  node app.js  ，按回车，启动nodejs项目
