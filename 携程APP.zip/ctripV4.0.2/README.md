## 实训项目
### web前端携程App

### 搭建项目结构
|---- ctrip
   |---- images      存放图片文件的目录
   |---- css         存放样式文件的目录
   |---- js          存放脚本文件的目录
   |---- libs        存放第三方库的目录
   |---- index.html  站点入口文件

### 编写项目代码
1. 搜索框
2. 轮播图
3. 导航分类
4. 链接
5. tab选项切换


### 实训目标
1. 学生选择一个主题（外卖，电商，音乐，电影，新闻）
2. 通过实践的知识点，完成一个项目（首页，详情，列表，个人中心..）
html,
html5,
css,
css3,
javascript,
swiper

ajax
nodejs

3. 页面布局结构 html
块级元素
特点： 独占一行显示（width:100%） , 划分页面结构
div , h1~h6, form , table , header , section , nav , footer 
ul , ol , p

行内元素
特点：在同一行显示，不能直接设置宽度高度，修饰页面细节 
span ,a , i , b , u , del ,strong

行内块元素
特点：在同一行显示，可以直接设置宽度高度，修饰页面细节 
img , button , input , audio , video ,canvas

4. 页面外观表现 css
盒子模型
思维模型： margin + border + padding + content
思维模型： 外边距 + 边框 + 内边距 + 宽高

背景
background-color
background-image
background-repeat
background-size
background-position
background-origin
background-clip


字体
font-size
font-family
font-style
font-weight

浮动
flaot: left
flaot: right
clear: both

定位
position: relative (父元素)
position: absolute (子元素)
position: fixed
top
right
bottom
left

弹性属性 （flex布局）
父元素
display: flex
justify-content: flex-start  center flex-end   X
align-items: flex-start center flex-end        Y 
子元素
flex-grow
flex-shrink
flex-basis

转换 transform 
旋转  位移  缩放
transform : rotate(0deg)  translate(x,y)  scale(1)
创建3d容器
transform-style: presver-3d
过度  transition
动画  @keyframes   animation

5. 页面行为逻辑 javascript
1. 变量
2. 语句
3. 函数
4. 事件
5. DOM
6. BOM 
7. 字符串、数组、对象
8. 编码思想


6. 创建动态网页(拓展)
nodejs  编写服务端的处理逻辑
6.0.1  下载nodejs并安装成功 （win7,8,10）
6.0.2  检查是否安装 ,
在命令面板上，
node -v  , npm -v ，显示版本号，表示安装成功
6.0.3  安装nodemon 工具，自动启动nodejs项目的工具
在命令面板上，
输入 npm install -g nodemon
nodemon -v        ，显示版本号，表示安装成功




































ajax    实现数据前后端交互


### 第一次周末课布置任务
1. 每个学生选择一个主题
2. 编写一个页面