// 编写渲染数据的模板函数
let template = data => {
    let str = ``;
    for (let i = 0; i < data.length; i++) {
        str += `
                <div class="swiper-slide">
                    <a href="#">
                        <img src="${data[i].src}" alt="">
                    </a>
                </div>
            `
    }
    // 渲染拼接的字符串
    document.querySelector(".swiper-wrapper").innerHTML = str;
}
// 编写函数处理轮播图
let banner = () => {
    // 假数据
    // let data = [
    //     { src: "./images/p1.jpg" },
    //     { src: "./images/p2.jpg" },
    //     { src: "./images/p3.jpg" },
    //     { src: "./images/p4.jpg" }
    // ]
    // 接口地址：
    // 地址： http://172.168.0.99:8080/banner/index
    // 方式： get 
    // 是否为JSONP: 是

    // 调用ajax方法
    $.ajax({
        url: "http://172.168.0.99:8080/banner/index",//接口地址
        type: "get",// 请求方式
        dataType: "jsonp", //表示执行 jsonp 逻辑
        jsonpCallback: "jsonp522", // 响应文本中的回调函数名称
        success(res) {
            // console.log(res);
            //  把字符串转成对象
            let obj = JSON.parse(res);
            // console.log(obj);
            // 判断响应的数据是否为正确数据
            if (obj.code == "200") {
                // 渲染数据
                template(obj.data);
                // 创建当前轮播图的实例
                var s1 = new Swiper('.swiper-container', {
                    autoplay: 2000,//可选选项，自动滑动
                    pagination: '.swiper-pagination',
                    loop: true,
                })
                // 调用设置搜索框效果的方法
                search();
                // 调用设置导航区块位置的方法
                scroll2();
            }

        },
        error(err) {
            console.log("请求失败");
        }
    })
}
// 编写函数处理tab选项切换
let tab = () => {
    // 1.0 获取页面相关元素
    let navItems = document.querySelectorAll(".tabnav-top li");
    let contentItems = document.querySelectorAll(".tabnav-bottom .item")
    // 2.0 事件绑定
    // 循环
    for (let i = 0; i < navItems.length; i++) {
        // 事件
        navItems[i].onclick = () => {
            // 3.0 书写程序处理逻辑
            // 获取当前点击的li标签的索引值
            let index = navItems[i].dataset.index;
            // console.log(index);
            // 排他思想
            for (let j = 0; j < navItems.length; j++) {
                // 移除类名
                navItems[j].className = "";
                contentItems[j].className = "item ";
            }
            // 给当前点击的li标签设置类名
            navItems[index].className = "active";
            contentItems[index].className = "item current";
        }
    }

}
// 编写函数处理搜索框背景透明度
let search = () => {
    // 1.0 获取页面相关元素
    let headerBox = document.querySelector(".header-box");
    let bannerImage = document.querySelector(".banner img");

    // 2.0 记录轮播图的高度
    let height = 0;
    bannerImage.onload = () => {
        height = bannerImage.height - 60;
    }
    // 3.0 监听页面滚动
    window.onscroll = () => {
        // 4.0 处理透明度的逻辑
        // 获取页面超出浏览器顶部的大小
        let ttop = document.documentElement.scrollTop || document.body.scrollTop;
        let opacity = 0;
        // 判断页面是否超出轮播图
        if (ttop >= height) {
            opacity = 1;
        } else {
            opacity = ttop / height;
        }
        // 设置headerBox标签设置透明度
        headerBox.style['backgroundColor'] = `rgba(255,255,255,${opacity})`;
    }
}

// 编写函数处理触摸滑动效果
let touchEv = () => {
    // 声明变量
    let startX = 0; //记录手指按下的坐标位置
    let moveX = 0;//记录手指滑动的坐标位置
    let resX = 0;//记录手指滑动的距离
    let curX = 0;//记录导航条当前的位置
    let isTouchStart = false;//记录手指是否按下
    let flag = false; //判断手指是否滑动
    // 获取相关的标签
    let ulElement = document.querySelector(".connav-top-box ul");
    let liElements = document.querySelectorAll(".connav-top-box ul li");
    // console.log(ulElement);
    // 记录最后一个选项的宽度
    let resWidth = -liElements[liElements.length - 1].offsetWidth;
    // console.log(resWidth);
    // 手指按下导航条
    ulElement.ontouchstart = event => {
        startX = event.touches[0].pageX;
        // console.log(startX);
        isTouchStart = true;
    }
    // 手指在页面滑动
    document.ontouchmove = event => {
        // 判断手指滑动
        flag = false;
        // 判断手指按下
        if (isTouchStart) {
            moveX = event.touches[0].pageX;
            // console.log(moveX);
            resX = moveX - startX + curX;
            // 判断 向右边移动
            if (resX > 0) {
                resX = 0;
            }
            // 判断 向左边移动
            if (resX < resWidth) {
                resX = resWidth;
            }
            // 设置ul标签的位置
            ulElement.style['transform'] = `translateX(${resX}px)`
        }
    }

    // 手指松开页面
    document.ontouchend = () => {
        curX = resX; // 记录ul标签的当前的位置
        isTouchStart = false;//设置布尔值为false ,意味着手指抬起
    }
    // 实现移动端tab切换效果（轻触逻辑）
    [...liElements].forEach((dom, index) => {
        // 声明变量 记录手指按下到手指松开的时间
        let time = 0;
        let startTime = 0;
        // 手指按下
        dom.addEventListener('touchstart', () => {
            // 当前时间的毫秒值
            startTime = new Date().getTime();
            flag = true;
        })
        // 手指松开
        dom.addEventListener('touchend', () => {
            time = new Date().getTime() - startTime;
            console.log(time);
            // 符合轻触条件
            if (time < 150 && flag) {
                // 循环li标签数组
                for (let i = 0; i < liElements.length; i++) {
                    liElements[i].className = ""
                }
                liElements[index].className = "active";
            }
            flag = false;
        })
    })

}

// 编写函数实现滚动监听，固定导航区块
let scroll2 = () => {
    // 获取相关的元素
    let connav = document.querySelector(".connav");
    let headerBox = document.querySelector(".header-box");
    let height = headerBox.offsetHeight;
    let offsetTop = connav.offsetTop;
    // 滚动事件监听
    window.addEventListener('scroll', () => {
        // 获取页面被浏览器捐掉的高度
        let ttop = document.documentElement.scrollTop;
        // console.log(offsetTop,ttop);
        // 判断
        if (ttop > (offsetTop + height)) {
            // 设置connav的位置脚本(固定定位)
            connav.style['position'] = "fixed";
            connav.style['top'] = height + "px";
        } else {
            // 设置connav的位置脚本（没有定位）
            connav.style['position'] = "static";
        }
    })

}

// 编写函数实现滚动加载数据
// 获取加载图标信息
let loadingElement = document.querySelector(".loading");
let isLoading = true;//开关
let index = 0;
// 步骤1：渲染数据
let render = data => {
    // 获取列表ul标签
    let leftBox = document.querySelector("#leftBox");
    let rightBox = document.querySelector("#rightBox");
    data.forEach((item, index) => {
        let liCreate = document.createElement("li");
        let str = `
            <a href="#">
                <div><img src="${item.src}" alt=""><i>地址-${index}</i></div>
                <div><h3>${item.title}</h3></div>
                <div><p>${item.content}</p></div>
                <div style="display:${item.price.length == 0 ? 'none' : 'block'}">
                    <span class="price"><b>￥${item.price}</b>起</span>
                    <span class="message">${item.msg}条评论</span>
                </div>
            </a>
        `;
        liCreate.innerHTML = str;
        if (index % 2 == 0) { // 0 ,2 ,4 6, 8 
            leftBox.appendChild(liCreate);
        } else { // 1,3,5,7,9
            rightBox.appendChild(liCreate);
        }
    })
}
// 步骤2：获取数据
let getData = (url, page, pageSize) => {
    $.ajax({
        url: url, //请求接口地址
        type: "get",//请求方式
        dataType: "jsonp", //执行jsonp逻辑
        jsonpCallback: "jsonp523",//回调函数的名称
        data: {//提交给服务端的参数
            page,
            pageSize
        },
        beforeSend() {
            // 显示正在加载的提示图标
            loadingElement.style['display'] = "block";
            // 设置布尔值为false(关门)
            isLoading = false;
        },
        success(res) {
            // 转对象
            let obj = JSON.parse(res);
            // 判断数据是否获取成功
            if (obj.code == "200") {
                // 设置延迟函数
                let delay = setTimeout(
                    () => {
                        // 隐藏正在加载的图标
                        loadingElement.style['display'] = "none";
                        // 设置布尔值为true（开门）
                        isLoading = true;
                        // 释放延迟函数
                        delay = null;
                        // 判断是否
                        if (obj.data.length == 0) {
                            // ...
                            alert("没有更多数据了。不用滚动了");
                            // 终止执行代码
                            return;
                        }
                        // 渲染数据
                        render(obj.data);
                        // 设置页面
                        index = page + 1;
                        // 给正在加载的图标标签设置自定义属性
                        loadingElement.setAttribute(
                            "data-index",
                            index
                        )
                    },
                    500
                )

            }
        },
        error(err) {
            console.log(err)
        }
    })
}
// 步骤3：滚动加载
let loadingFunc = () => {
    let delay2 = null;
    // 监听页面滚动
    window.addEventListener("scroll", () => {
        // 可视化窗口高度
        let winHeight = window.innerHeight;
        // 页面高度
        let pageHeight = document.documentElement.offsetHeight;
        // 被浏览器卷掉的高度
        let sTop = document.documentElement.scrollTop;
        // 防抖思想
        if (delay2) clearTimeout(delay2);
        delay2 = setTimeout(
            () => {
                // 执行获取的方法
                // 判断是否符合加载数据的条件
                let resHeight = pageHeight - (winHeight + sTop)
                if (resHeight < 100 && isLoading) {
                    // 获取当前loading标签上的自定义属性值
                    let page = loadingElement.getAttribute("data-index") - 0;
                    getData(
                        "http://127.0.0.1:8080/list/content",
                        page,
                        5
                    );
                }
            },
            300
        )
    })
}

// 编写初始化函数
let init = () => {
    // 方法1
    banner();
    // 方法2
    tab();
    // 方法3
    // search();
    // 方法4
    touchEv();
    // 方法5
    // scroll2();
    // 方法6 
    loadingFunc();
    // 初始化列表数据
    getData(
        "http://127.0.0.1:8080/list/content",
        0,
        5
    );
}
// 初始化
init();
