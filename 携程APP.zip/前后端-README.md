## 实训项目
### 前端项目(视觉界面)
#### ctrip 
- html 
- html5
- css  
- css3
- javascript 
- swiper
- jquery
- ajax

#### 首页
1. 轮播图
2. 导航栏
3. 旅游信息列表


### 后端项目(数据接口)
#### project
- nodejs 
- express 
- mysql

#### 服务端
1. 服务器地址
[] http://127.0.0.1:8080      本地IP地址
[] http://172.168.0.99:8080   局域IP地址

2. 静态资源
- 资源文件
.html
.css
.js
图片
字体文件

- 地址
[] http://127.0.0.1:8080/static/xxx.jpg
[] http://172.168.0.99:8080/static/xxx.jpg

3. 编写数据接口
- 接口说明 
3.0.1 接口地址： 测试
+ 请求地址 
hostUrl/test
+ 请求方式  
get  JSONP跨域
+ 是否提交参数
无
+ 响应数据
jsonp522(数据)


3.0.2 接口地址2： 轮播图接口
+ 请求地址
/banner/index

+ 请求方式
get 是jsonp接口

+ 是否提交参数
无
+ 响应数据
```
jsonp522('{"code":"200","data":[]}')

```




